(function( $ ) {
    $(function() {
        $( '#cmbab_color_picker_id' ).wpColorPicker();         
    });
})( jQuery );